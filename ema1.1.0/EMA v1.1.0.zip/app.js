//app.js
App({
    globalData: {
        api: "https://api.bidadada.top",
        user: null,
    },
})